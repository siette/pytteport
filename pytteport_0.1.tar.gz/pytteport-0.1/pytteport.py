#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys, serial, time
from serial import *

VERSION = "0.1"

# Internal pytteport parameters
CFG_TIME = 10
CFG_TIMES = 1

# pyserial parameters
CFG_PORT = "/dev/ttyUSB0" # Number of device (starts at zero)
CFG_BAUDRATE = 9600 # Baudrate
CFG_BYTESIZE = EIGHTBITS # Number of databits
CFG_PARITY = PARITY_NONE # Parity checking
CFG_STOPBITS = STOPBITS_ONE # Number of stopbits
CFG_TIMEOUT = None # Set a timeout value, None for waiting forever

# Messages
MSG_WELCOME = "USAGE: pytteport [time (ms)]"
MSG_START = "pytteport started:"
MSG_ERRORPORT = "Culd not open port\n"
MSG_RTSENABLED = "RTS line was established to logic level 1"
MSG_UNKNOWN = "[!] Error: "
MSG_QUIT = "Game over!"

# Functions
def Quit(ser, str = MSG_QUIT):
    ser.close()
    sys.exit(str)

def EnableRTS(ser):
    ser.setRTS(1)
    print MSG_RTSENABLED


# Cheking argv
try:
    CFG_TIME = float(sys.argv[1])
except IndexError:
    sys.exit(MSG_WELCOME)

# Starting the curre
print MSG_START
ser = serial.Serial()
ser.port = CFG_PORT
ser.baudrate = CFG_BAUDRATE
ser.bytesize = CFG_BYTESIZE
ser.parity = CFG_PARITY
ser.STOPBITS = CFG_STOPBITS
ser.timeout = CFG_TIMEOUT

# Open serial port
try:
    ser.open()
except SerialException, e:
    Quit(ser, MSG_UNKNOWN + e.message)

try:
    while True:
        EnableRTS(ser)
        time.sleep(CFG_TIME)
        Quit(ser)
except KeyboardInterrupt:
    Quit(ser)
